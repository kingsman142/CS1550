/*
	FUSE: Filesystem in Userspace
	Copyright (C) 2001-2007  Miklos Szeredi <miklos@szeredi.hu>

	This program can be distributed under the terms of the GNU GPL.
	See the file COPYING.
*/

#define	FUSE_USE_VERSION 26

#include <fuse.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>

//size of a disk block
#define	BLOCK_SIZE 512

//we'll use 8.3 filenames
#define	MAX_FILENAME 8
#define	MAX_EXTENSION 3

//How many files can there be in one directory?
#define MAX_FILES_IN_DIR (BLOCK_SIZE - sizeof(int)) / ((MAX_FILENAME + 1) + (MAX_EXTENSION + 1) + sizeof(size_t) + sizeof(long))

//The attribute packed means to not align these things
struct cs1550_directory_entry
{
	int nFiles;	//How many files are in this directory.
				//Needs to be less than MAX_FILES_IN_DIR

	struct cs1550_file_directory
	{
		char fname[MAX_FILENAME + 1];	//filename (plus space for nul)
		char fext[MAX_EXTENSION + 1];	//extension (plus space for nul)
		size_t fsize;					//file size
		long nStartBlock;				//where the first block is on disk
	} __attribute__((packed)) files[MAX_FILES_IN_DIR];	//There is an array of these

	//This is some space to get this to be exactly the size of the disk block.
	//Don't use it for anything.  
	char padding[BLOCK_SIZE - MAX_FILES_IN_DIR * sizeof(struct cs1550_file_directory) - sizeof(int)];
} ;

typedef struct cs1550_root_directory cs1550_root_directory;

#define MAX_DIRS_IN_ROOT (BLOCK_SIZE - sizeof(int)) / ((MAX_FILENAME + 1) + sizeof(long))

struct cs1550_root_directory
{
	int nDirectories;	//How many subdirectories are in the root
						//Needs to be less than MAX_DIRS_IN_ROOT
	struct cs1550_directory
	{
		char dname[MAX_FILENAME + 1];	//directory name (plus space for nul)
		long nStartBlock;				//where the directory block is on disk
	} __attribute__((packed)) directories[MAX_DIRS_IN_ROOT];	//There is an array of these

	//This is some space to get this to be exactly the size of the disk block.
	//Don't use it for anything.  
	char padding[BLOCK_SIZE - MAX_DIRS_IN_ROOT * sizeof(struct cs1550_directory) - sizeof(int)];
} ;

typedef struct cs1550_directory_entry cs1550_directory_entry;

//How much data can one block hold?
#define	MAX_DATA_IN_BLOCK (BLOCK_SIZE)

struct cs1550_disk_block
{
	//All of the space in the block can be used for actual data
	//storage.
	char data[MAX_DATA_IN_BLOCK];
};

typedef struct cs1550_disk_block cs1550_disk_block;

#define MAX_FAT_ENTRIES (BLOCK_SIZE/sizeof(short))

struct cs1550_file_alloc_table_block {
	short table[MAX_FAT_ENTRIES];
};

typedef struct cs1550_file_alloc_table_block cs1550_fat_block;

//Global variables that allow for very fast and easy writing later on
cs1550_root_directory root;
cs1550_fat_block fat;

#define START_ALLOC_BLOCK 2 //block 0 = root; block 1 = FAT; start allocation of directories and files at block 2 in the allocation table

//Write the root data from a given pointer to disk at block 0
static void write_root(cs1550_root_directory* root_on_disk){
	FILE* disk = fopen(".disk", "r+b");
	fwrite(root_on_disk, BLOCK_SIZE, 1, disk);
	fclose(disk);
}

//Write the FAT data from a given pointer to disk at block 1
static void write_fat(cs1550_fat_block* fat_on_disk){
	FILE* disk = fopen(".disk", "r+b");
	fseek(disk, BLOCK_SIZE, SEEK_SET);
	fwrite(fat_on_disk, BLOCK_SIZE, 1, disk);
	fclose(disk);
}

/*
 * Called whenever the system wants to know the file attributes, including
 * simply whether the file exists or not. 
 *
 * man -s 2 stat will show the fields of a stat structure
 */
static int cs1550_getattr(const char *path, struct stat *stbuf)
{
	int res = 0;

	//Store the path data for easy navigation later on
	char directory[MAX_FILENAME+1];
	char filename[MAX_FILENAME+1];
	char extension[MAX_EXTENSION+1];
	strcpy(directory, "");
	strcpy(filename, "");
	strcpy(extension, "");

	if(strlen(path) != 1){ //If the path is not just "/", parse the necessary directory, filename, and extension if possible
		sscanf(path, "/%[^/]/%[^.].%s", directory, filename, extension);
	}	

	//If any of the variables are longer than the 8.3 file naming convention, return the ENAMETOOLONG error
	if(strlen(directory) > MAX_FILENAME || strlen(filename) > MAX_FILENAME || strlen(extension) > MAX_EXTENSION){
		return -ENAMETOOLONG;
	}

	//Clear the data in stbuf JUST IN CASE
	memset(stbuf, 0, sizeof(struct stat));
 
	//The path is just the root directory
	if(strcmp(path, "/") == 0){
		stbuf->st_mode = S_IFDIR | 0755;
		stbuf->st_nlink = 2;
		res = 0;
		return res;
	} else{ //Navigate through the file system to find the correct directory and/or file
		if(strcmp(directory, "") == 0){ //If the directory is empty, return that the file cannot be found
			res = -ENOENT;
			return res;
		} else{
			int i = 0;
			struct cs1550_directory dir;
			strcpy(dir.dname, "");
			dir.nStartBlock = -1;

			for(i = 0; i < root.nDirectories; i++){ //Find the subdirectory in the root's array of directories
				struct cs1550_directory curr_dir = root.directories[i];
				if(strcmp(curr_dir.dname, directory) == 0){ //This current directory and our search directory names match
					dir = curr_dir;
					break;
				}
			}

			if(strcmp(dir.dname, "") == 0){ //No directory was found, so return an ENOENT error
				res = -ENOENT;
				return res;
			}

			if(strcmp(filename, "") == 0){ //No more left in the path to traverse; the user was only looking to get the attributes of a directory
				res = 0;
				stbuf->st_mode = S_IFDIR | 0755;
				stbuf->st_nlink = 2;
				return res; //Return a success
			}

			FILE* disk = fopen(".disk", "r+b");
			int location_on_disk = BLOCK_SIZE*dir.nStartBlock;
			fseek(disk, location_on_disk, SEEK_SET);
	
			cs1550_directory_entry dir_entry;
			dir_entry.nFiles = 0;
			memset(dir_entry.files, 0, MAX_FILES_IN_DIR*sizeof(struct cs1550_file_directory));

			int num_items_successfully_read = fread(&dir_entry, BLOCK_SIZE, 1, disk); //Read in the directory's data, such as its files contained within
			fclose(disk);
	
			if(num_items_successfully_read == 1){ //One block was successfully read, so proceed
				struct cs1550_file_directory file;
				strcpy(file.fname, "");
				strcpy(file.fext, "");
				file.fsize = 0;
				file.nStartBlock = -1;
	
				for(i = 0; i < dir_entry.nFiles; i++){ //Iterate over the files in the directory
					struct cs1550_file_directory curr_file = dir_entry.files[i];
					if(strcmp(file.fname, filename) == 0 && strcmp(file.fext, extension) == 0){ //Both the current filename and file extension match
														    //the filename and file extension we're looking for.
						file = curr_file;
						break;
					}
				}

				if(file.nStartBlock = -1){ //No file was found, so return a file not found error
					res = -ENOENT;
					return res;
				} else{ //The file we were looking for was found!
					res = 0;
					stbuf->st_mode = S_IFREG | 0666;
					stbuf->st_nlink = 1;
					stbuf->st_size = file.fsize;
					return res; //Return success
				}
			}
		}
	}
	
	return res;
}

/* 
 * Called whenever the contents of a directory are desired. Could be from an 'ls'
 * or could even be when a user hits TAB to do autocompletion
 */
static int cs1550_readdir(const char *path, void *buf, fuse_fill_dir_t filler,
			 off_t offset, struct fuse_file_info *fi)
{
	//Since we're building with -Wall (all warnings reported) we need
	//to "use" every parameter, so let's just cast them to void to
	//satisfy the compiler
	(void) offset;
	(void) fi;
	
	//the filler function allows us to add entries to the listing
	//read the fuse.h file for a description (in the ../include dir)
	filler(buf, ".", NULL, 0);
	filler(buf, "..", NULL, 0);

	//Parse the path, which is in the form: root/destination/filename.extension
	char* destination = strtok(path, "/");
	char* filename = strtok(NULL, ".");
	char* extension = strtok(NULL, ".");

	//Each of these iff statements first checks if the string is null; if not, check the length.
	//If the length is longer than the 8.3 file naming convention we're using, return the error ENAMETOOLONG.
	if((destination && destination[0]) && strlen(destination) > MAX_FILENAME){
		return -ENAMETOOLONG;
	}
	if((filename && filename[0]) && strlen(filename) > MAX_FILENAME){
		return -ENAMETOOLONG;
	}
	if((extension && extension[0]) && strlen(extension) > MAX_EXTENSION){
		return -ENAMETOOLONG;
	}

	//Enter the root
	if(strcmp(path, "/") == 0){
		int i = 0;
		for(i = 0; i < MAX_DIRS_IN_ROOT; i++){ //Iterate over all of the directories in the root; if their name is non-empty, print for the user using filler()
			char* directory_name = root.directories[i].dname;
			if(strcmp(directory_name, "") != 0){
				filler(buf, directory_name, NULL, 0);
			}
		}

		return 0;
	} else{
		int i = 0;
		struct cs1550_directory dir; //Initialize a directory for file checking later on
		strcpy(dir.dname, "");
		dir.nStartBlock = -1;

		for(i = 0; i < MAX_DIRS_IN_ROOT; i++){ //Iterate over the directories in the root until we find the directory with a matching name with the path
			if(strcmp(destination, root.directories[i].dname) == 0){
				dir = root.directories[i];
				break;
			}
		}

		if(strcmp(dir.dname, "") == 0){ //No directory was found in the root, so return file not found error
			return -ENOENT;
		} else{ //The proper directory was found, so read the directory
			FILE* disk = fopen(".disk", "rb+");
			int location_on_disk = dir.nStartBlock*BLOCK_SIZE;
			fseek(disk, location_on_disk, SEEK_SET);

			cs1550_directory_entry directory;
			directory.nFiles = 0;
			memset(directory.files, 0, MAX_FILES_IN_DIR*sizeof(struct cs1550_file_directory));

			int num_items_read = fread(&directory, BLOCK_SIZE, 1, disk); //Read the directory data from memory to iterate over its files
			fclose(disk);

			int j = 0;
			for(j = 0; j < MAX_FILES_IN_DIR; j++){ //Iterate over the non-empty filenames in this directory and print them to the user using filler()
				struct cs1550_file_directory file_dir = directory.files[j];
				if(strcmp(file_dir.fname, "") != 0){
					filler(buf, file_dir.fname, NULL, 0);
				}
			}
		}
	}

	return 0;
}

/* 
 * Creates a directory. We can ignore mode since we're not dealing with
 * permissions, as long as getattr returns appropriate ones for us.
 */
static int cs1550_mkdir(const char *path, mode_t mode)
{
	(void) path;
	(void) mode;
	
	//Remove the / from the path
	char* path_short = path+1;

	//path will be in the format of /directory/sub_directory
	char* directory; //The first directory in the 2-level file system
	char* sub_directory; //The directory within the root's directory

	//Parse the two strings
	directory = strtok(path, "/");
	sub_directory = strtok(NULL, "/"); //NULL indicates to continue where strtok left off at

	if(strlen(directory) > MAX_FILENAME){ //The main directory (e.g. /exampleFileNameHere/... is too long; max of 8 characters
		return -ENAMETOOLONG;
	} else if(sub_directory && sub_directory[0]){ //The user passed in a sub directory; this is illegal in our two-level file system
						      //because the second level should only be files.  Return that permission was denied.
		return -EPERM;
	}

	int h = 0;
	for(h = 0; h < MAX_DIRS_IN_ROOT; h++){ //Scan through the directories in the root; if any match the directory we're trying to create,
					       //inform the user that that directory already exists.
		if(strcmp(root.directories[h].dname, directory) == 0){
			return -EEXIST;
		}
	}

	int i = 0;
	for(i = 0; i < MAX_DIRS_IN_ROOT; i++){ //Iterate through the root's directories/folders
		if(strcmp(root.directories[i].dname, "") == 0){ //If this folder is nameless (it doesn't exist yet), use it to create a new directory
			struct cs1550_directory new_dir_in_root;
			strcpy(new_dir_in_root.dname, directory); //Copy the user's new directory name into this struct
			
			int j = 0;
			for(j = START_ALLOC_BLOCK; j < MAX_FAT_ENTRIES; j++){ //Iterate over the FAT to find a new block to store the directory in
									      //NOTE: j starts at 2 because on the disk:
									      //	index 0 = root
									      //	index 1 = FAT
				if(fat.table[j] == 0){ //Currently nothing allocated at this index
					fat.table[j] = EOF; //Directory only requires 1 block
					new_dir_in_root.nStartBlock = j;
					break;
				}
			}

			FILE* disk = fopen(".disk", "r+b");
			int location_on_disk = BLOCK_SIZE*new_dir_in_root.nStartBlock; //The location on the disk for this directory is the starting block * 512
			fseek(disk, location_on_disk, SEEK_SET);
			cs1550_directory_entry dir;
			dir.nFiles = 0; //Directory begins with 0 files in it
			
			int num_items_read = fread(&dir, BLOCK_SIZE, 1, disk);
			
			if(num_items_read == 1){ //fread returned successfully with 1 item
				memset(&dir, 0, sizeof(struct cs1550_directory_entry)); //Clear the directory data we just read in JUST IN CASE
				fwrite(&dir, BLOCK_SIZE, 1, disk); //Write the new directory data
				fclose(disk);

				//Update the root with its new data and write it to disk, as well as the FAT
				root.nDirectories++;
				root.directories[i] = new_dir_in_root;				

				write_root(&root);
				write_fat(&fat);
			} else{ //There was an error reading in the data from disk, so just close the file
				fclose(disk);
			}

			return 0;
		}


	}

	return 0; //Return success since no errors occurred by this point
}

/* 
 * Removes a directory.
 */
static int cs1550_rmdir(const char *path)
{
	(void) path;
    return 0;
}

/* 
 * Does the actual creation of a file. Mode and dev can be ignored.
 *
 */
static int cs1550_mknod(const char *path, mode_t mode, dev_t dev)
{
	(void) mode;
	(void) dev;
	return 0;
}

/*
 * Deletes a file
 */
static int cs1550_unlink(const char *path)
{
    (void) path;

    return 0;
}

/* 
 * Read size bytes from file into buf starting from offset
 *
 */
static int cs1550_read(const char *path, char *buf, size_t size, off_t offset,
			  struct fuse_file_info *fi)
{
	(void) buf;
	(void) offset;
	(void) fi;
	(void) path;

	//check to make sure path exists
	//check that size is > 0
	//check that offset is <= to the file size
	//read in data
	//set size and return, or error

	size = 0;

	return size;
}

/* 
 * Write size bytes from buf into file starting from offset
 *
 */
static int cs1550_write(const char *path, const char *buf, size_t size, 
			  off_t offset, struct fuse_file_info *fi)
{
	(void) buf;
	(void) offset;
	(void) fi;
	(void) path;

	//check to make sure path exists
	//check that size is > 0
	//check that offset is <= to the file size
	//write data
	//set size (should be same as input) and return, or error

	return size;
}

/******************************************************************************
 *
 *  DO NOT MODIFY ANYTHING BELOW THIS LINE
 *
 *****************************************************************************/

/*
 * truncate is called when a new file is created (with a 0 size) or when an
 * existing file is made shorter. We're not handling deleting files or 
 * truncating existing ones, so all we need to do here is to initialize
 * the appropriate directory entry.
 *
 */
static int cs1550_truncate(const char *path, off_t size)
{
	(void) path;
	(void) size;

    return 0;
}


/* 
 * Called when we open a file
 *
 */
static int cs1550_open(const char *path, struct fuse_file_info *fi)
{
	(void) path;
	(void) fi;
    /*
        //if we can't find the desired file, return an error
        return -ENOENT;
    */

    //It's not really necessary for this project to anything in open

    /* We're not going to worry about permissions for this project, but 
	   if we were and we don't have them to the file we should return an error

        return -EACCES;
    */

    return 0; //success!
}

/*
 * Called when close is called on a file descriptor, but because it might
 * have been dup'ed, this isn't a guarantee we won't ever need the file 
 * again. For us, return success simply to avoid the unimplemented error
 * in the debug log.
 */
static int cs1550_flush (const char *path , struct fuse_file_info *fi)
{
	(void) path;
	(void) fi;

	return 0; //success!
}


//register our new functions as the implementations of the syscalls
static struct fuse_operations hello_oper = {
    .getattr	= cs1550_getattr,
    .readdir	= cs1550_readdir,
    .mkdir	= cs1550_mkdir,
	.rmdir = cs1550_rmdir,
    .read	= cs1550_read,
    .read	= cs1550_read,
    .read	= cs1550_read,
    .write	= cs1550_write,
	.mknod	= cs1550_mknod,
	.unlink = cs1550_unlink,
	.truncate = cs1550_truncate,
	.flush = cs1550_flush,
	.open	= cs1550_open,
};

//Don't change this.
int main(int argc, char *argv[])
{
	return fuse_main(argc, argv, &hello_oper, NULL);
}
